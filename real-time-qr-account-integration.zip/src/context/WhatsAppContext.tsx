import React, {
  createContext,
  useContext,
  useEffect,
  useRef,
  useState,
  useCallback,
} from 'react';
import { io, Socket } from 'socket.io-client';
import axios from 'axios';
import type { WAUser, WAChat, WAMessage, ClientStatus } from '../types/whatsapp';

const BACKEND = 'http://localhost:3001';

interface WhatsAppContextValue {
  status: ClientStatus;
  qrCode: string | null;
  user: WAUser | null;
  chats: WAChat[];
  selectedChat: WAChat | null;
  messages: WAMessage[];
  loadingChats: boolean;
  loadingMessages: boolean;
  errorMsg: string | null;
  loadingPercent: number;
  startClient: () => void;
  logout: () => void;
  selectChat: (chat: WAChat) => void;
  sendMessage: (chatId: string, message: string) => Promise<void>;
  refreshChats: () => void;
}

const WhatsAppContext = createContext<WhatsAppContextValue | null>(null);

export function WhatsAppProvider({ children }: { children: React.ReactNode }) {
  const socketRef = useRef<Socket | null>(null);

  const [status, setStatus] = useState<ClientStatus>('disconnected');
  const [qrCode, setQrCode] = useState<string | null>(null);
  const [user, setUser] = useState<WAUser | null>(null);
  const [chats, setChats] = useState<WAChat[]>([]);
  const [selectedChat, setSelectedChat] = useState<WAChat | null>(null);
  const [messages, setMessages] = useState<WAMessage[]>([]);
  const [loadingChats, setLoadingChats] = useState(false);
  const [loadingMessages, setLoadingMessages] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [loadingPercent, setLoadingPercent] = useState(0);

  // ── Fetch chats ───────────────────────────────────────────────────────────
  const fetchChats = useCallback(async () => {
    setLoadingChats(true);
    try {
      const res = await axios.get<WAChat[]>(`${BACKEND}/api/chats`);
      setChats(res.data);
    } catch (err: any) {
      console.error('fetchChats error:', err.message);
    } finally {
      setLoadingChats(false);
    }
  }, []);

  // ── Fetch messages ────────────────────────────────────────────────────────
  const fetchMessages = useCallback(async (chatId: string) => {
    setLoadingMessages(true);
    try {
      const res = await axios.get<WAMessage[]>(
        `${BACKEND}/api/chats/${encodeURIComponent(chatId)}/messages?limit=50`
      );
      setMessages(res.data);
      // mark as read
      await axios.post(
        `${BACKEND}/api/chats/${encodeURIComponent(chatId)}/read`
      ).catch(() => {});
    } catch (err: any) {
      console.error('fetchMessages error:', err.message);
    } finally {
      setLoadingMessages(false);
    }
  }, []);

  // ── Select chat ───────────────────────────────────────────────────────────
  const selectChat = useCallback(
    (chat: WAChat) => {
      setSelectedChat(chat);
      setMessages([]);
      fetchMessages(chat.id);
      // update unread count
      setChats((prev) =>
        prev.map((c) => (c.id === chat.id ? { ...c, unreadCount: 0 } : c))
      );
    },
    [fetchMessages]
  );

  // ── Send message ──────────────────────────────────────────────────────────
  const sendMessage = useCallback(
    async (chatId: string, message: string) => {
      try {
        await axios.post(
          `${BACKEND}/api/chats/${encodeURIComponent(chatId)}/send`,
          { message }
        );
      } catch (err: any) {
        console.error('sendMessage error:', err.message);
        throw err;
      }
    },
    []
  );

  // ── Start client ──────────────────────────────────────────────────────────
  const startClient = useCallback(() => {
    setErrorMsg(null);
    setStatus('loading');
    socketRef.current?.emit('start_client');
  }, []);

  // ── Logout ────────────────────────────────────────────────────────────────
  const logout = useCallback(async () => {
    try {
      await axios.post(`${BACKEND}/api/logout`);
      setStatus('disconnected');
      setUser(null);
      setChats([]);
      setMessages([]);
      setSelectedChat(null);
      setQrCode(null);
    } catch (err) {
      console.error('logout error:', err);
    }
  }, []);

  // ── Socket.io ─────────────────────────────────────────────────────────────
  useEffect(() => {
    const socket = io(BACKEND, {
      transports: ['websocket', 'polling'],
      reconnection: true,
      reconnectionDelay: 2000,
    });
    socketRef.current = socket;

    socket.on('connect', () => {
      console.log('[Socket] Connected');
    });

    socket.on('status', ({ status: s, user: u, qr }) => {
      setStatus(s as ClientStatus);
      setUser(u);
      if (qr) setQrCode(qr);
      if (s === 'ready' && u) fetchChats();
    });

    socket.on('qr', ({ qr }) => {
      setQrCode(qr);
      setStatus('qr');
    });

    socket.on('loading', ({ percent }: { percent: number; message: string }) => {
      setLoadingPercent(percent);
      setStatus('loading');
    });

    socket.on('authenticated', () => {
      setStatus('authenticated');
      setQrCode(null);
    });

    socket.on('ready', ({ user: u }) => {
      setStatus('ready');
      setUser(u);
      setQrCode(null);
      fetchChats();
    });

    socket.on('disconnected', (_: any) => {
      setStatus('disconnected');
      setUser(null);
      setQrCode(null);
      setChats([]);
    });

    socket.on('auth_failure', ({ message: msg }) => {
      setStatus('error');
      setErrorMsg(msg || 'Authentication failed');
    });

    socket.on('error', ({ message: msg }) => {
      setStatus('error');
      setErrorMsg(msg);
    });

    // New incoming message
    socket.on('new_message', (msg: any) => {
      // Add to messages if this chat is selected
      setSelectedChat((sel) => {
        if (sel && (msg.from === sel.id || msg.to === sel.id)) {
          setMessages((prev) => [
            ...prev,
            {
              id: msg.id,
              body: msg.body,
              type: msg.type,
              from: msg.from,
              to: msg.to,
              fromMe: msg.fromMe,
              timestamp: msg.timestamp,
              hasMedia: msg.hasMedia,
              isForwarded: msg.isForwarded,
              ack: 3,
              author: msg.author,
            },
          ]);
        }
        return sel;
      });

      // Update chat list last message
      setChats((prev) => {
        const chatId = msg.fromMe ? msg.to : msg.from;
        return prev.map((c) => {
          if (c.id === chatId) {
            return {
              ...c,
              lastMessage: {
                body: msg.body,
                type: msg.type,
                fromMe: msg.fromMe,
                timestamp: msg.timestamp,
              },
              timestamp: msg.timestamp,
              unreadCount: msg.fromMe ? c.unreadCount : c.unreadCount + 1,
            };
          }
          return c;
        }).sort((a, b) => b.timestamp - a.timestamp);
      });
    });

    // Outgoing message confirmation
    socket.on('message_sent', (msg: any) => {
      setMessages((prev) => {
        const exists = prev.find((m) => m.id === msg.id);
        if (exists) return prev;
        return [
          ...prev,
          {
            id: msg.id,
            body: msg.body,
            type: 'chat',
            from: '',
            to: msg.to,
            fromMe: true,
            timestamp: msg.timestamp,
            hasMedia: false,
            isForwarded: false,
            ack: 1,
            author: null,
          },
        ];
      });
    });

    return () => {
      socket.disconnect();
    };
  }, [fetchChats]);

  // ── Check backend status on mount ─────────────────────────────────────────
  useEffect(() => {
    axios
      .get(`${BACKEND}/api/status`)
      .then(({ data }) => {
        setStatus(data.status as ClientStatus);
        setUser(data.user);
        if (data.qr) setQrCode(data.qr);
        if (data.status === 'ready' && data.user) fetchChats();
      })
      .catch(() => {
        setErrorMsg('Cannot connect to backend. Please start the server.');
        setStatus('error');
      });
  }, [fetchChats]);

  const value: WhatsAppContextValue = {
    status,
    qrCode,
    user,
    chats,
    selectedChat,
    messages,
    loadingChats,
    loadingMessages,
    errorMsg,
    loadingPercent,
    startClient,
    logout,
    selectChat,
    sendMessage,
    refreshChats: fetchChats,
  };

  return (
    <WhatsAppContext.Provider value={value}>{children}</WhatsAppContext.Provider>
  );
}

export function useWhatsApp() {
  const ctx = useContext(WhatsAppContext);
  if (!ctx) throw new Error('useWhatsApp must be used inside WhatsAppProvider');
  return ctx;
}
