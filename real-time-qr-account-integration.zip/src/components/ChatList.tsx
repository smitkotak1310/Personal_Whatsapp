import { useState, useMemo } from 'react';
import { useWhatsApp } from '../context/WhatsAppContext';
import type { WAChat } from '../types/whatsapp';
import { formatTimestamp } from '../utils/time';
import {
  FiSearch,
  FiMoreVertical,
  FiMessageSquare,
  FiRefreshCw,
  FiLogOut,
  FiUser,
} from 'react-icons/fi';
import { BsCheck2All, BsMicFill, BsImageFill, BsCameraVideoFill } from 'react-icons/bs';
import { SiWhatsapp } from 'react-icons/si';

function Avatar({ chat, size = 'md' }: { chat: WAChat; size?: 'sm' | 'md' | 'lg' }) {
  const dim = size === 'sm' ? 'w-10 h-10' : size === 'lg' ? 'w-14 h-14' : 'w-12 h-12';
  const textSize = size === 'sm' ? 'text-base' : size === 'lg' ? 'text-2xl' : 'text-lg';

  if (chat.profilePic) {
    return (
      <img
        src={chat.profilePic}
        alt={chat.name}
        className={`${dim} rounded-full object-cover flex-shrink-0`}
        onError={(e) => {
          (e.target as HTMLImageElement).style.display = 'none';
        }}
      />
    );
  }

  const initials = chat.name
    .split(' ')
    .slice(0, 2)
    .map((w) => w[0])
    .join('')
    .toUpperCase();

  const colors = ['#d9fdd3', '#fff3cd', '#fce4ec', '#e3f2fd', '#f3e5f5', '#e8f5e9'];
  const bg = colors[chat.name.charCodeAt(0) % colors.length];

  return (
    <div
      className={`${dim} rounded-full flex items-center justify-center flex-shrink-0 font-semibold ${textSize}`}
      style={{ backgroundColor: bg, color: '#555' }}
    >
      {initials || <FiUser />}
    </div>
  );
}

function MessagePreview({ chat }: { chat: WAChat }) {
  const msg = chat.lastMessage;
  if (!msg) return <span className="text-gray-400 text-sm italic">No messages</span>;

  const getIcon = () => {
    switch (msg.type) {
      case 'image': return <BsImageFill className="inline text-gray-400 mr-1" />;
      case 'video': return <BsCameraVideoFill className="inline text-gray-400 mr-1" />;
      case 'audio':
      case 'ptt': return <BsMicFill className="inline text-gray-400 mr-1" />;
      default: return null;
    }
  };

  const getLabel = () => {
    switch (msg.type) {
      case 'image': return 'Photo';
      case 'video': return 'Video';
      case 'audio': return 'Audio';
      case 'ptt': return 'Voice message';
      default: return msg.body;
    }
  };

  return (
    <span className="text-[13px] text-gray-500 truncate flex items-center gap-0.5">
      {msg.fromMe && <BsCheck2All className="text-[#53bdeb] flex-shrink-0 mr-0.5" />}
      {getIcon()}
      {getLabel()}
    </span>
  );
}



export default function ChatList() {
  const {
    chats, selectedChat, loadingChats, user,
    selectChat, logout, refreshChats,
  } = useWhatsApp();

  const [search, setSearch] = useState('');
  const [showMenu, setShowMenu] = useState(false);

  const filtered = useMemo(() => {
    if (!search.trim()) return chats;
    const q = search.toLowerCase();
    return chats.filter(
      (c) =>
        c.name.toLowerCase().includes(q) ||
        c.lastMessage?.body.toLowerCase().includes(q)
    );
  }, [chats, search]);

  return (
    <div className="flex flex-col h-full bg-white border-r border-gray-200">
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-3 bg-[#f0f2f5] h-[60px]">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-[#dfe5e7] flex items-center justify-center text-gray-600 font-semibold text-lg overflow-hidden">
            {user?.name?.[0]?.toUpperCase() || <FiUser className="text-gray-500" />}
          </div>
          <span className="text-gray-800 font-medium text-sm truncate max-w-[120px]">
            {user?.name || 'WhatsApp'}
          </span>
        </div>
        <div className="flex items-center gap-1">
          <button
            onClick={refreshChats}
            className="p-2 rounded-full hover:bg-gray-200 text-gray-500 transition-colors"
            title="Refresh chats"
          >
            <FiRefreshCw className={`text-xl ${loadingChats ? 'animate-spin' : ''}`} />
          </button>
          <button className="p-2 rounded-full hover:bg-gray-200 text-gray-500 transition-colors" title="New chat">
            <FiMessageSquare className="text-xl" />
          </button>
          <div className="relative">
            <button
              onClick={() => setShowMenu(!showMenu)}
              className="p-2 rounded-full hover:bg-gray-200 text-gray-500 transition-colors"
            >
              <FiMoreVertical className="text-xl" />
            </button>
            {showMenu && (
              <div className="absolute right-0 top-10 bg-white rounded-lg shadow-lg border border-gray-100 py-1 z-50 w-44">
                <button
                  onClick={() => { logout(); setShowMenu(false); }}
                  className="w-full flex items-center gap-3 px-4 py-2.5 text-sm text-gray-700 hover:bg-gray-50 transition-colors"
                >
                  <FiLogOut className="text-gray-500" />
                  Log out
                </button>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Search */}
      <div className="px-3 py-2 bg-white border-b border-gray-100">
        <div className="flex items-center bg-[#f0f2f5] rounded-full px-4 py-2 gap-2">
          <FiSearch className="text-gray-400 flex-shrink-0" />
          <input
            type="text"
            placeholder="Search or start new chat"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="bg-transparent text-sm text-gray-700 outline-none w-full placeholder-gray-400"
          />
        </div>
      </div>

      {/* Chat list */}
      <div className="flex-1 overflow-y-auto">
        {loadingChats && chats.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-40 gap-3">
            <div className="w-8 h-8 border-2 border-[#00a884] border-t-transparent rounded-full animate-spin" />
            <p className="text-sm text-gray-400">Loading chats…</p>
          </div>
        ) : filtered.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-40 gap-2 px-6 text-center">
            <SiWhatsapp className="text-gray-300 text-4xl" />
            <p className="text-sm text-gray-400">
              {search ? 'No chats match your search' : 'No chats yet'}
            </p>
          </div>
        ) : (
          filtered.map((chat) => (
            <ChatItem
              key={chat.id}
              chat={chat}
              isSelected={selectedChat?.id === chat.id}
              onSelect={() => selectChat(chat)}
            />
          ))
        )}
      </div>
    </div>
  );
}

function ChatItem({
  chat,
  isSelected,
  onSelect,
}: {
  chat: WAChat;
  isSelected: boolean;
  onSelect: () => void;
}) {
  return (
    <button
      onClick={onSelect}
      className={`w-full flex items-center gap-3 px-3 py-3 hover:bg-[#f5f6f6] transition-colors cursor-pointer border-b border-gray-100
        ${isSelected ? 'bg-[#f0f2f5]' : ''}`}
    >
      <Avatar chat={chat} />
      <div className="flex-1 min-w-0">
        <div className="flex items-center justify-between mb-0.5">
          <span className="font-medium text-[15px] text-gray-900 truncate flex-1 text-left">
            {chat.name}
          </span>
          <span
            className={`text-xs flex-shrink-0 ml-2 ${
              chat.unreadCount > 0 ? 'text-[#00a884] font-medium' : 'text-gray-400'
            }`}
          >
            {chat.timestamp ? formatTimestamp(chat.timestamp) : ''}
          </span>
        </div>
        <div className="flex items-center justify-between">
          <div className="flex-1 min-w-0 text-left">
            <MessagePreview chat={chat} />
          </div>
          {chat.unreadCount > 0 && (
            <span className="ml-2 flex-shrink-0 min-w-[20px] h-5 rounded-full bg-[#00a884] text-white text-xs flex items-center justify-center px-1 font-medium">
              {chat.unreadCount > 99 ? '99+' : chat.unreadCount}
            </span>
          )}
          {chat.muted && !chat.unreadCount && (
            <span className="ml-2 text-gray-400 text-xs">🔇</span>
          )}
        </div>
      </div>
    </button>
  );
}
