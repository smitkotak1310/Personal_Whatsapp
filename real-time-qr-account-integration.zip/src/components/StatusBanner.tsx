import { useWhatsApp } from '../context/WhatsAppContext';

export default function StatusBanner() {
  const { status } = useWhatsApp();

  if (status === 'ready') return null;

  const banners: Record<string, { text: string; className: string }> = {
    loading: {
      text: '⏳ Connecting to WhatsApp…',
      className: 'bg-yellow-500 text-white',
    },
    authenticated: {
      text: '🔐 Authenticated! Loading your chats…',
      className: 'bg-blue-500 text-white',
    },
    disconnected: {
      text: '⚠️ Disconnected from WhatsApp',
      className: 'bg-gray-600 text-white',
    },
    error: {
      text: '❌ Connection error. Please restart the backend server.',
      className: 'bg-red-500 text-white',
    },
    qr: {
      text: '📱 Scan the QR code with WhatsApp on your phone',
      className: 'bg-[#00a884] text-white',
    },
  };

  const banner = banners[status];
  if (!banner) return null;

  return (
    <div className={`w-full text-center text-sm py-1.5 px-4 font-medium ${banner.className}`}>
      {banner.text}
    </div>
  );
}
