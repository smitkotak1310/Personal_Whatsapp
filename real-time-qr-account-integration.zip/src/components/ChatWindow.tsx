import React, { useEffect, useRef, useState } from 'react';
import { useWhatsApp } from '../context/WhatsAppContext';
import type { WAMessage } from '../types/whatsapp';
import { formatMessageTime, formatDateDivider, isSameDay } from '../utils/time';
import {
  FiSearch,
  FiMoreVertical,
  FiSend,
  FiSmile,
  FiPaperclip,
  FiMic,
} from 'react-icons/fi';
import {
  BsCheck2,
  BsCheck2All,
  BsMicFill,
  BsImageFill,
  BsCameraVideoFill,
  BsFileEarmarkFill,
} from 'react-icons/bs';
import { SiWhatsapp } from 'react-icons/si';
import { FiUser } from 'react-icons/fi';

function TickIcon({ fromMe, ack }: { fromMe: boolean; ack: number }) {
  if (!fromMe) return null;
  if (ack >= 3) return <BsCheck2All className="text-[#53bdeb] text-sm" />;
  if (ack >= 2) return <BsCheck2All className="text-gray-400 text-sm" />;
  return <BsCheck2 className="text-gray-400 text-sm" />;
}

function MessageBubble({ msg }: { msg: WAMessage }) {
  const isMe = msg.fromMe;

  const renderContent = () => {
    switch (msg.type) {
      case 'image':
        return (
          <div className="flex flex-col gap-1">
            <div className="flex items-center gap-2 text-gray-500 text-sm">
              <BsImageFill />
              <span>Photo</span>
            </div>
            {msg.body && <p className="text-sm text-gray-700 mt-1">{msg.body}</p>}
          </div>
        );
      case 'video':
        return (
          <div className="flex items-center gap-2 text-gray-500 text-sm">
            <BsCameraVideoFill />
            <span>Video</span>
          </div>
        );
      case 'ptt':
        return (
          <div className="flex items-center gap-2 text-gray-500 text-sm">
            <BsMicFill className="text-[#00a884]" />
            <div className="flex gap-0.5 items-center">
              {Array.from({ length: 20 }).map((_, i) => (
                <div
                  key={i}
                  className="w-0.5 bg-current rounded-full"
                  style={{ height: `${Math.random() * 14 + 4}px`, opacity: 0.6 }}
                />
              ))}
            </div>
          </div>
        );
      case 'audio':
        return (
          <div className="flex items-center gap-2 text-gray-500 text-sm">
            <BsMicFill />
            <span>Audio</span>
          </div>
        );
      case 'document':
        return (
          <div className="flex items-center gap-2 text-gray-500 text-sm">
            <BsFileEarmarkFill />
            <span>Document</span>
          </div>
        );
      case 'sticker':
        return <div className="text-2xl">🎭 Sticker</div>;
      default:
        return (
          <p className="text-[14.5px] text-gray-800 leading-relaxed whitespace-pre-wrap break-words">
            {msg.body}
          </p>
        );
    }
  };

  return (
    <div className={`flex ${isMe ? 'justify-end' : 'justify-start'} mb-1`}>
      <div
        className={`relative max-w-[65%] rounded-lg px-3 py-2 shadow-sm
          ${isMe ? 'bg-[#d9fdd3] rounded-tr-none' : 'bg-white rounded-tl-none'}`}
        style={{ minWidth: '80px' }}
      >
        {renderContent()}
        <div className="flex items-center justify-end gap-1 mt-1">
          <span className="text-[11px] text-gray-400 whitespace-nowrap">
            {formatMessageTime(msg.timestamp)}
          </span>
          <TickIcon fromMe={isMe} ack={msg.ack} />
        </div>
      </div>
    </div>
  );
}

function DateDivider({ timestamp }: { timestamp: number }) {
  return (
    <div className="flex items-center justify-center my-3">
      <span className="bg-[#e9edef] text-gray-600 text-xs rounded-full px-3 py-1 font-medium shadow-sm">
        {formatDateDivider(timestamp)}
      </span>
    </div>
  );
}

export default function ChatWindow() {
  const {
    selectedChat,
    messages,
    loadingMessages,
    sendMessage,
  } = useWhatsApp();

  const [input, setInput] = useState('');
  const [sending, setSending] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  useEffect(() => {
    if (selectedChat) inputRef.current?.focus();
  }, [selectedChat]);

  const handleSend = async () => {
    if (!input.trim() || !selectedChat || sending) return;
    const text = input.trim();
    setInput('');
    setSending(true);
    try {
      await sendMessage(selectedChat.id, text);
    } catch {
      // Error handled in context
    } finally {
      setSending(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  // ── Empty state ──────────────────────────────────────────────────────────
  if (!selectedChat) {
    return (
      <div className="flex-1 flex flex-col items-center justify-center bg-[#f0f2f5] gap-4">
        <div className="w-24 h-24 rounded-full bg-[#d9fdd3] flex items-center justify-center">
          <SiWhatsapp className="text-[#00a884] text-5xl" />
        </div>
        <div className="text-center">
          <h2 className="text-2xl font-light text-gray-600 mb-2">WhatsApp Web</h2>
          <p className="text-gray-400 text-sm max-w-[320px] leading-relaxed">
            Send and receive messages without keeping your phone online.
            <br />
            Use WhatsApp on up to 4 linked devices and 1 phone at the same time.
          </p>
        </div>
        <div className="flex items-center gap-2 text-gray-400 text-sm border border-gray-200 rounded-full px-4 py-2 bg-white">
          <div className="w-2 h-2 rounded-full bg-[#00a884] animate-pulse" />
          End-to-end encrypted
        </div>
      </div>
    );
  }

  // ── Render messages with date dividers ───────────────────────────────────
  const messageGroups: React.ReactElement[] = [];
  messages.forEach((msg, idx) => {
    const prevMsg = messages[idx - 1];
    const showDate = !prevMsg || !isSameDay(prevMsg.timestamp, msg.timestamp);
    if (showDate) {
      messageGroups.push(<DateDivider key={`d-${msg.id}`} timestamp={msg.timestamp} />);
    }
    messageGroups.push(<MessageBubble key={msg.id} msg={msg} />);
  });

  // Chat header avatar
  const initials = selectedChat.name
    .split(' ')
    .slice(0, 2)
    .map((w) => w[0])
    .join('')
    .toUpperCase();

  return (
    <div className="flex-1 flex flex-col h-full">
      {/* Header */}
      <div className="flex items-center gap-3 px-4 h-[60px] bg-[#f0f2f5] border-b border-gray-200 flex-shrink-0">
        <div className="flex items-center gap-3 flex-1 min-w-0">
          {selectedChat.profilePic ? (
            <img
              src={selectedChat.profilePic}
              alt={selectedChat.name}
              className="w-10 h-10 rounded-full object-cover"
              onError={(e) => {
                const el = e.target as HTMLImageElement;
                el.style.display = 'none';
              }}
            />
          ) : (
            <div className="w-10 h-10 rounded-full bg-[#dfe5e7] flex items-center justify-center text-gray-600 font-semibold">
              {initials || <FiUser />}
            </div>
          )}
          <div className="min-w-0">
            <p className="font-medium text-gray-900 text-[15px] truncate">
              {selectedChat.name}
            </p>
            <p className="text-xs text-gray-500">
              {selectedChat.isGroup ? 'Group' : 'click for contact info'}
            </p>
          </div>
        </div>
        <div className="flex items-center gap-1">
          <button className="p-2 rounded-full hover:bg-gray-200 text-gray-500 transition-colors">
            <FiSearch className="text-xl" />
          </button>
          <button className="p-2 rounded-full hover:bg-gray-200 text-gray-500 transition-colors">
            <FiMoreVertical className="text-xl" />
          </button>
        </div>
      </div>

      {/* Messages */}
      <div
        className="flex-1 overflow-y-auto px-4 py-3 space-y-0"
        style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg width='400' height='400' xmlns='http://www.w3.org/2000/svg'%3E%3Crect width='400' height='400' fill='%23e5ddd5'/%3E%3Cpath d='M20 20 L30 10 L40 20 L30 30 Z' fill='%23d4c9be' opacity='0.3'/%3E%3C/svg%3E")`,
          backgroundColor: '#efeae2',
        }}
      >
        {loadingMessages ? (
          <div className="flex items-center justify-center h-full gap-3">
            <div className="w-6 h-6 border-2 border-[#00a884] border-t-transparent rounded-full animate-spin" />
            <span className="text-gray-500 text-sm">Loading messages…</span>
          </div>
        ) : messages.length === 0 ? (
          <div className="flex items-center justify-center h-full">
            <div className="bg-[#e9edef] rounded-lg px-4 py-2">
              <p className="text-gray-600 text-sm text-center">
                No messages yet. Say hello! 👋
              </p>
            </div>
          </div>
        ) : (
          <>
            {messageGroups}
            <div ref={messagesEndRef} />
          </>
        )}
      </div>

      {/* Input bar */}
      <div className="flex items-center gap-2 px-3 py-2 bg-[#f0f2f5] border-t border-gray-200 flex-shrink-0">
        <button className="p-2 rounded-full hover:bg-gray-200 text-gray-500 transition-colors">
          <FiSmile className="text-2xl" />
        </button>
        <button className="p-2 rounded-full hover:bg-gray-200 text-gray-500 transition-colors">
          <FiPaperclip className="text-2xl" />
        </button>
        <div className="flex-1 bg-white rounded-full flex items-center px-4 py-2 shadow-sm">
          <input
            ref={inputRef}
            type="text"
            placeholder="Type a message"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={handleKeyDown}
            className="flex-1 outline-none text-[15px] text-gray-800 placeholder-gray-400 bg-transparent"
          />
        </div>
        <button
          onClick={input.trim() ? handleSend : undefined}
          className="p-2 rounded-full bg-[#00a884] hover:bg-[#008c6f] text-white transition-colors shadow-sm"
          title={input.trim() ? 'Send' : 'Voice message'}
        >
          {input.trim() ? (
            <FiSend className="text-xl" />
          ) : (
            <FiMic className="text-xl" />
          )}
        </button>
      </div>
    </div>
  );
}
