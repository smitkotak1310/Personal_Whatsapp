import ChatList from './ChatList';
import ChatWindow from './ChatWindow';

export default function MainLayout() {
  return (
    <div className="flex h-screen w-screen overflow-hidden bg-[#f0f2f5]">
      {/* Sidebar - Chat list */}
      <div className="w-[380px] min-w-[320px] max-w-[420px] flex-shrink-0 flex flex-col h-full shadow-sm">
        <ChatList />
      </div>

      {/* Main chat area */}
      <div className="flex-1 flex flex-col h-full min-w-0">
        <ChatWindow />
      </div>
    </div>
  );
}
