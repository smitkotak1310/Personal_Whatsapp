import { } from 'react';
import { useWhatsApp } from '../context/WhatsAppContext';
import { FiRefreshCw, FiSmartphone, FiWifi, FiAlertCircle } from 'react-icons/fi';
import { SiWhatsapp } from 'react-icons/si';

export default function QRScreen() {
  const { status, qrCode, loadingPercent, errorMsg, startClient } = useWhatsApp();

  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-[#f0f2f5]">
      {/* Top green bar */}
      <div className="absolute top-0 left-0 right-0 h-[220px] bg-[#00a884]" />

      <div className="relative z-10 flex flex-col items-center w-full max-w-[950px] mx-auto px-4">
        {/* Logo */}
        <div className="flex items-center gap-3 mb-6 mt-8">
          <SiWhatsapp className="text-white text-4xl" />
          <h1 className="text-white text-3xl font-light tracking-[0.15em] uppercase">
            WhatsApp Web
          </h1>
        </div>

        {/* Main card */}
        <div className="bg-white rounded-lg shadow-lg w-full flex flex-col md:flex-row overflow-hidden">
          {/* Left: instructions */}
          <div className="flex-1 p-8 md:p-12 flex flex-col justify-center border-b md:border-b-0 md:border-r border-gray-100">
            <h2 className="text-2xl font-light text-gray-800 mb-6">
              Use WhatsApp on your computer
            </h2>
            <ol className="space-y-5">
              {[
                { icon: <FiSmartphone className="text-[#00a884] text-xl shrink-0" />, text: 'Open WhatsApp on your phone' },
                {
                  icon: <div className="w-5 h-5 shrink-0 flex items-center justify-center rounded-full border-2 border-[#00a884] text-[#00a884] text-xs font-bold">⋮</div>,
                  text: 'Tap Menu on Android, or Settings on iPhone',
                },
                {
                  icon: <FiWifi className="text-[#00a884] text-xl shrink-0" />,
                  text: 'Tap Linked Devices and then Link a Device',
                },
                {
                  icon: <div className="w-5 h-5 shrink-0 flex items-center justify-center rounded-full bg-[#00a884] text-white text-xs font-bold">4</div>,
                  text: 'Point your phone camera at this screen to scan the QR code',
                },
              ].map(({ icon, text }, i) => (
                <li key={i} className="flex items-start gap-3 text-gray-600 text-[15px]">
                  {icon}
                  <span>{text}</span>
                </li>
              ))}
            </ol>

            <div className="mt-8 p-4 bg-[#f0f2f5] rounded-lg">
              <p className="text-sm text-gray-500 flex items-start gap-2">
                <FiAlertCircle className="text-[#00a884] shrink-0 mt-0.5" />
                WhatsApp Web connects to your real WhatsApp account. Messages are end-to-end encrypted.
              </p>
            </div>
          </div>

          {/* Right: QR code */}
          <div className="flex-shrink-0 flex flex-col items-center justify-center p-10 md:p-12 w-full md:w-[380px]">
            {status === 'error' && (
              <div className="flex flex-col items-center gap-4 text-center">
                <FiAlertCircle className="text-red-500 text-5xl" />
                <p className="text-gray-700 font-medium">Backend Not Connected</p>
                <p className="text-gray-500 text-sm max-w-[240px]">
                  {errorMsg || 'Could not reach the backend server. Please start it.'}
                </p>
                <div className="bg-gray-900 rounded-lg p-4 text-left mt-2 w-full">
                  <p className="text-green-400 text-xs font-mono">$ cd server</p>
                  <p className="text-green-400 text-xs font-mono">$ npm install</p>
                  <p className="text-green-400 text-xs font-mono">$ npm start</p>
                </div>
                <button
                  onClick={startClient}
                  className="mt-2 flex items-center gap-2 px-5 py-2.5 bg-[#00a884] text-white rounded-full text-sm font-medium hover:bg-[#008c6f] transition-colors"
                >
                  <FiRefreshCw className="text-base" />
                  Retry Connection
                </button>
              </div>
            )}

            {(status === 'loading' || status === 'authenticated') && (
              <div className="flex flex-col items-center gap-5 text-center">
                <div className="w-20 h-20 rounded-full border-4 border-[#00a884] border-t-transparent animate-spin" />
                <div>
                  <p className="text-gray-700 font-medium text-lg">
                    {status === 'authenticated' ? 'Connecting…' : 'Loading WhatsApp…'}
                  </p>
                  {loadingPercent > 0 && (
                    <p className="text-gray-500 text-sm mt-1">{loadingPercent}%</p>
                  )}
                  <p className="text-gray-400 text-xs mt-2 max-w-[200px]">
                    This may take a moment on first launch
                  </p>
                </div>
              </div>
            )}

            {status === 'disconnected' && !qrCode && (
              <div className="flex flex-col items-center gap-5 text-center">
                <div className="w-20 h-20 rounded-full bg-[#f0f2f5] flex items-center justify-center">
                  <SiWhatsapp className="text-[#00a884] text-4xl" />
                </div>
                <div>
                  <p className="text-gray-700 font-medium">Not Connected</p>
                  <p className="text-gray-500 text-sm mt-1">
                    Start the backend server to generate a QR code
                  </p>
                </div>
                <button
                  onClick={startClient}
                  className="flex items-center gap-2 px-5 py-2.5 bg-[#00a884] text-white rounded-full text-sm font-medium hover:bg-[#008c6f] transition-colors"
                >
                  <FiRefreshCw />
                  Connect
                </button>
              </div>
            )}

            {status === 'qr' && qrCode && (
              <div className="flex flex-col items-center gap-4">
                <div className="border-4 border-white shadow-lg rounded-xl overflow-hidden">
                  <img
                    src={qrCode}
                    alt="WhatsApp QR Code"
                    className="w-[220px] h-[220px] object-contain"
                  />
                </div>
                <div className="flex items-center gap-2 text-[#00a884] text-sm">
                  <div className="w-2 h-2 rounded-full bg-[#00a884] animate-pulse" />
                  Waiting for scan…
                </div>
                <button
                  onClick={startClient}
                  className="text-gray-400 hover:text-gray-600 text-xs flex items-center gap-1 transition-colors"
                >
                  <FiRefreshCw className="text-sm" />
                  Refresh QR
                </button>
              </div>
            )}
          </div>
        </div>

        <p className="mt-6 text-gray-500 text-sm text-center">
          Keep your phone connected while using WhatsApp Web
        </p>
      </div>
    </div>
  );
}
