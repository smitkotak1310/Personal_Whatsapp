export interface WAUser {
  name: string;
  number: string;
  platform?: string;
}

export interface WALastMessage {
  body: string;
  type: string;
  fromMe: boolean;
  timestamp: number;
}

export interface WAChat {
  id: string;
  name: string;
  isGroup: boolean;
  unreadCount: number;
  timestamp: number;
  lastMessage: WALastMessage | null;
  profilePic: string | null;
  pinned: boolean;
  muted: boolean;
}

export interface WAMessage {
  id: string;
  body: string;
  type: string;
  from: string;
  to: string;
  fromMe: boolean;
  timestamp: number;
  hasMedia: boolean;
  isForwarded: boolean;
  ack: number;
  author: string | null;
}

export type ClientStatus =
  | 'disconnected'
  | 'loading'
  | 'qr'
  | 'authenticated'
  | 'ready'
  | 'error';

export const ACK_LABELS: Record<number, string> = {
  '-1': 'Error',
  0: 'Pending',
  1: 'Sent',
  2: 'Delivered',
  3: 'Read',
  4: 'Played',
};
