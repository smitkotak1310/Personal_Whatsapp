import { format, isToday, isYesterday, isThisWeek } from 'date-fns';

export function formatTimestamp(unixSeconds: number): string {
  const date = new Date(unixSeconds * 1000);

  if (isToday(date)) {
    return format(date, 'HH:mm');
  }
  if (isYesterday(date)) {
    return 'Yesterday';
  }
  if (isThisWeek(date)) {
    return format(date, 'EEEE'); // e.g. Monday
  }
  return format(date, 'dd/MM/yyyy');
}

export function formatMessageTime(unixSeconds: number): string {
  return format(new Date(unixSeconds * 1000), 'HH:mm');
}

export function formatDateDivider(unixSeconds: number): string {
  const date = new Date(unixSeconds * 1000);
  if (isToday(date)) return 'Today';
  if (isYesterday(date)) return 'Yesterday';
  return format(date, 'MMMM d, yyyy');
}

export function isSameDay(ts1: number, ts2: number): boolean {
  const d1 = new Date(ts1 * 1000);
  const d2 = new Date(ts2 * 1000);
  return (
    d1.getFullYear() === d2.getFullYear() &&
    d1.getMonth() === d2.getMonth() &&
    d1.getDate() === d2.getDate()
  );
}
