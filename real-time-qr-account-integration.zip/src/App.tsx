import { WhatsAppProvider, useWhatsApp } from './context/WhatsAppContext';
import QRScreen from './components/QRScreen';
import MainLayout from './components/MainLayout';
import StatusBanner from './components/StatusBanner';

function AppContent() {
  const { status } = useWhatsApp();

  if (status === 'ready') {
    return (
      <div className="flex flex-col h-screen">
        <StatusBanner />
        <div className="flex-1 overflow-hidden">
          <MainLayout />
        </div>
      </div>
    );
  }

  return <QRScreen />;
}

export default function App() {
  return (
    <WhatsAppProvider>
      <AppContent />
    </WhatsAppProvider>
  );
}
